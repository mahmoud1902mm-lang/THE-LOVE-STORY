export default async function handler(req, res) {
  if (req.method !== 'POST') {
    res.setHeader('Allow', 'POST');
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const data = req.body && typeof req.body === 'object' ? req.body : {};
    const apiKey = process.env.RESEND_API_KEY;

    if (!apiKey) {
      return res.status(500).json({ error: 'RESEND_API_KEY is not configured' });
    }

    const rows = Object.entries(data)
      .filter(([, value]) => value !== undefined && value !== null && String(value).trim() !== '')
      .map(([key, value]) => `<tr><td style="padding:8px;border-bottom:1px solid #eee;font-weight:bold">${escapeHtml(key)}</td><td style="padding:8px;border-bottom:1px solid #eee">${escapeHtml(String(value)).replace(/\n/g, '<br>')}</td></tr>`)
      .join('');

    const response = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${apiKey}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        from: 'THE LOVE STORY <onboarding@resend.dev>',
        to: ['mahmoud1902mm@gmail.com'],
        subject: '❤️ بيانات جديدة من THE LOVE STORY',
        html: `<!doctype html><html lang="ar" dir="rtl"><body style="font-family:Arial,sans-serif;line-height:1.7"><h2>بيانات جديدة من الموقع ❤️</h2><table style="width:100%;border-collapse:collapse">${rows}</table></body></html>`
      })
    });

    const result = await response.json().catch(() => ({}));
    if (!response.ok) {
      console.error('Resend error:', result);
      return res.status(502).json({ error: 'Email delivery failed' });
    }

    return res.status(200).json({ success: true, id: result.id });
  } catch (error) {
    console.error('send-data error:', error);
    return res.status(500).json({ error: 'Internal server error' });
  }
}

function escapeHtml(value) {
  return value
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}
